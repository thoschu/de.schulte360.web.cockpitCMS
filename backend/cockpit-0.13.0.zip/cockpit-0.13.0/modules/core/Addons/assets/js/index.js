(function($){

    App.module.controller("addons", function($scope, $rootScope, $http){

        $scope.addons = ADDONS || [];

    });

})(jQuery);